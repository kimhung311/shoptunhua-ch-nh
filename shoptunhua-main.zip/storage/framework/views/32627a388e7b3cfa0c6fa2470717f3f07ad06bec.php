

<?php $__env->startSection('content'); ?>
    <div class="card-header">Users</div>

    
<br><br><br>
    <table id="product-list" class="table table-bordered table-hover table-striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($user->name); ?></th>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <?php if(Cache::has('user-is-online-' . $user->id)): ?>
                                <span class="text-success"><img src="https://image.winudf.com/v2/image1/d2hhdHNlZW4uc3dpZnRzYWZlLm9yZy53aGF0c2Vlbl9pY29uXzE1NDc0MDI1MTBfMDU3/icon.png?w=&fakeurl=1" width="40px" alt=""> Online</span>
                            <?php else: ?>
                                <span class="text-secondary"><img src="http://cdn.onlinewebfonts.com/svg/img_107628.png" width="40px" alt=""> Offline</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/customer/check_online_user.blade.php ENDPATH**/ ?>