<?php $__env->startSection('title', 'List Order'); ?>


<?php $__env->startSection('breadcrumbName', 'Order Management'); ?>


<?php $__env->startSection('breadcrumbMenu', 'List Order'); ?>


<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="/backend/css/orders/order-list.css">
<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
    <script src="/backend/js/orders/order-list.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item active" aria-current="page">List Order</li>
        
    </ol>
</nav>
    
    

    
    <?php echo $__env->make('errors.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('admin.orders._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('admin.orders._table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>