<?php $__env->startSection('title', 'Create Category'); ?>


<?php $__env->startSection('breadcrumbName', 'Category Management'); ?>


<?php $__env->startSection('breadcrumbMenu', 'Create Category'); ?>


<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="/css/categories/category-create.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">List Category</a></li>
        <li class="breadcrumb-item active" aria-current="page">Create</li>
        </ol>
  </nav>
  <br>
    <h3 style="text-align: center">Tạo sản phẩm</h3>
  <br>


    <?php echo $__env->make('errors.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <form action="<?php echo e(route('admin.category.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="">Nhập/thêm danh sách sản phẩm:</label>
            <input class="form-control" type="text" name="category_name" placeholder="category name" style="width:450px"><br>

            <label for="">Ảnh:</label><br>
            <input  type="file" name="thumbnail" placeholder="category name">
        </div>

       

        <div class="form-group">
            <a href="<?php echo e(route('admin.category.index')); ?>" class="btn btn-secondary">List Category</a>
            <button type="submit" class="btn btn-primary">Create</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>