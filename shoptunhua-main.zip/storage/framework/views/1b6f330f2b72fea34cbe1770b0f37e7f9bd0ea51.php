<?php $__env->startSection('title', 'List Product'); ?>


<?php $__env->startSection('breadcrumbName', 'Post Management'); ?>


<?php $__env->startSection('breadcrumbMenu', 'List Post'); ?>


<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="/admin/css/product/product-list.css">
<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">List Products</li>
        </ol>
    </nav>
    
    <?php echo $__env->make('admin.products._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    
    <p ><a  class="btn btn-outline-success" href="<?php echo e(route('admin.product.create')); ?>">Create</a></p>
    
    
    

    
    

    
    <?php if(Session::has('error')): ?>
        <p class="text-danger"><?php echo e(Session::get('error')); ?></p>
    <?php endif; ?>

    
    <table id="product-list" class="table table-bordered table-hover table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Images</th>
                <th>Prices</th>
                <th>Status</th>
                <th>Quantity</th>
                <th>Hot</th>
                <th>Category_name</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($products)): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td>
                            
                            
                            <img src="/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="img-fluid" style="width: 40px; height: auto;" >

                        </td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->status); ?></td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td><?php echo e($product->hot); ?></td>
                        <td><?php echo e($product->category->name); ?></td>
                        
                        <td><a href="<?php echo e(route('admin.product.show', $product->id)); ?>" class="btn btn-outline-info">Detail</a></td>
                        <td><a href="<?php echo e(route('admin.product.edit', $product->id)); ?>" class="btn btn-outline-info">Edit</a></td>
                        <td>
                            <form action="<?php echo e(route('admin.product.destroy', $product->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <input type="submit" value="Delete" class="btn btn-outline-danger" onclick="return confirm('Are you sure DELETE PRODUCT?')" class="btn btn-danger" />
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/products/index.blade.php ENDPATH**/ ?>