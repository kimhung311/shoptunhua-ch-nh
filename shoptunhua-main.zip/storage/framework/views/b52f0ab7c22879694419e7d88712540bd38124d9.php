<br>
<br>
    <?php $__env->startSection('content'); ?>
    <br><br>
        
        <h1 style="text-align: center"> Danh sách  tài khoản người dùng</h1>
            
            <?php if(Session::has('success')): ?>
                <p class="text-success"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>

            
            <?php if(Session::has('error')): ?>
                <p class="text-danger"><?php echo e(Session::get('error')); ?></p>
            <?php endif; ?>
            
            <?php echo $__env->make('admin.user._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            
           
           <br> <p ><a  class="btn btn-outline-success" href="<?php echo e(route('admin.user.create')); ?>">Tạo tài khoản cho người dùng</a></p>
            <table id="user-list" class="table table-bordered table-hover table-striped">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>Tên</th>
                        <th>Email</th>
                        <th>role_id</th>
                        <th>Trạng thái</th>
                        <th>Ngày tạo</th>
                        <th colspan="3">Action</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($key+1); ?></th>
                            <th><?php echo e($admin->name); ?></th>
                            <th><?php echo e($admin->email); ?></th>
                            <th><?php echo e($admin->role_id); ?></th>
                            <th> <?php echo $__env->make('admin.user.alert_admin_status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </th>
                            <th><?php echo e($admin->created_at); ?></th>
                            
                            
                            <td><a class="btn btn-outline-secondary" href=" <?php echo e(route('admin.user.edit', $admin->id)); ?>"> Đổi Mật Khẩu</a></td>
                            <td>
                                <form action="<?php echo e(route('admin.user.destroy', $admin->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <input type="submit" value="Delete" class="btn btn-outline-danger" onclick="return confirm('Are you sure DELETE User?')" class="btn btn-danger" />
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
        </table>
        <?php echo e($admins->links()); ?>

    <?php $__env->stopSection(); ?>    
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/user/index.blade.php ENDPATH**/ ?>