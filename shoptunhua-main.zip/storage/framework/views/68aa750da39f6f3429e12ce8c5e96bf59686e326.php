
<?php if($admin->role_id == \App\Models\Admin::STATUS[1]): ?>
    <div class="btn btn-success" role="alert">Admin</div>
<?php elseif($admin->role_id == \App\Models\Admin::STATUS[2]): ?>
    <div class="btn btn-warning" role="alert">Editor</div>
<?php else: ?>
    <div class="btn btn-info" role="alert">shipper</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/user/alert_admin_status.blade.php ENDPATH**/ ?>