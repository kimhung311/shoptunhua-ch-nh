
<?php if($products->product_images): ?>
    <?php $__currentLoopData = $products->product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img class="hover-img" src="<?php echo e($url->url); ?>" alt="">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endif; ?><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/Homepage/img-hover.blade.php ENDPATH**/ ?>