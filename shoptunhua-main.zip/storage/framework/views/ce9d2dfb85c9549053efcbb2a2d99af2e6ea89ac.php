<nav class="navbar navbar-light bg-light justify-content-between">
    
    <form class="form-inline">
      <input class="form-control mr-sm-2" name ="name" type="search" placeholder="name" aria-label="Search">
      <br>
      <input type="date" class="form-control mr-sm-2" name="date" type="search" placeholder="date" aria-label="Search">
        <div class="col-md-4">
          <select class="form-control" name="status">
              <option value="">Trạng thái đơn hàng</option>
              <option value="1"  <?php echo e(!empty($status) && $status=='1'); ?>>chưa thanh toán</option>
              <option value="2"  <?php echo e(!empty($status) && $status=="2"); ?>>Đã thanh toán online</option>
              <option value="3"  <?php echo e(!empty($status) && $status=="3"); ?>> shipper đang đi giao hàng</option>
              <option value="4"  <?php echo e(!empty($status) && $status=="4"); ?>> cancel đơn hàng</option>
              <option value="5"  <?php echo e(!empty($status) && $status=="5"); ?>> hoàn thành</option>
              

            </select>
      </div>
    <hr>
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </nav><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/orders/_search.blade.php ENDPATH**/ ?>