<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="/css/categories/category-edit.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Chỉnh sửa sản phẩm</a></li>
            <li class="breadcrumb-item active" aria-current="page">Edit</li>
        </ol>
    </nav>
    <h4>Edit Category</h4>
    <form action="<?php echo e(route('admin.category.update', $category->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group mb-3">
            <label for="">Tên  danh mục sản phẩm</label><br>
            <input type="text" name="category_name" value="<?php echo e($category->name); ?>" class="form-control" style="width:450px">
            <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <br>

            <label for="">Ảnh</label> <br>
            <img src="/<?php echo e($category->thumbnail); ?>" width=150px alt=""><br>
            <input type="file" name="thumbnail" value="<?php echo e(($category->thumbnail)); ?>">
                <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        


        <div class="form-group">
            <a href="<?php echo e(route('admin.category.index')); ?>" class="btn btn-secondary">List Category</a>
            <input type="submit" name="submit" value="Update" class="btn btn-primary">
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>