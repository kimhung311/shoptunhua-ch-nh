<table id="product-list" class="table table-striped table-bordered dataTable">
    <thead>
        <tr>

            <th>STT</th>
            <th>Fullname</th>
            <th>Order day</th>
            <th>Status</th>
            <th>order pending</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if(!empty($orders)): ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($order->user->name); ?></td>
                    
                    <td><?php echo e($order->created_at); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td>
                        <?php echo $__env->make('admin.orders.parts.alert_order_status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.order.show', $order->id)); ?>" class="btn btn-secondary">Order Detail</a>                        
                    </td>
                    <td><a href="<?php echo e(route('admin.order.edit', $order->id)); ?>" class="btn btn-info">Update Status</a></td>
                    <td>
                        <form action="<?php echo e(route('admin.order.destroy', $order->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" value="Delete" onclick="return confirm('Are you sure DELETE Order?')" class="btn btn-danger" />
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>

<?php echo e($orders->appends(request()->input())->links()); ?>

<?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/orders/_table.blade.php ENDPATH**/ ?>