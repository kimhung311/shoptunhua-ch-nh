<?php $__env->startSection('title', 'List Category'); ?>


<?php $__env->startSection('breadcrumbName', 'Category Management'); ?>


<?php $__env->startSection('breadcrumbMenu', 'List Category'); ?>


<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="/css/categories/category-list.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<br>
<br>
<br>
<br>
    <nav aria-label="breadcrumb"style=" text-align:center">
        <ol class="breadcrumb" >
            <li class="breadcrumb-item active" aria-current="page"><h1 >List Category</h1></li>
        </ol>
   </nav>
    

    
    
    <p><a class="btn btn-outline-info" href="<?php echo e(route('admin.category.create')); ?>">Tạo Mới</a></p>
    <br>
    
    

    
    

    
    <?php if(Session::has('error')): ?>
        <p class="text-danger"><?php echo e(Session::get('error')); ?></p>
    <?php endif; ?>


    
    <table id="category-list" class="table table-bordered table-hover table-striped">
        <thead>
            <tr>
                <th>Stt</th>
                <th>Danh Mục</th>
                <th>Sản phẩm của danh mục</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($categories)): ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td><img src="/<?php echo e($category->thumbnail); ?>" width=150px alt=""></td>

                        
                        
                        <td><a class="btn btn-outline-info" href="<?php echo e(route('admin.category.edit', $category->id)); ?>">Chỉnh sửa</a></td>
                        <td>
                            <form action="<?php echo e(route('admin.category.destroy', $category->id)); ?>" method="post" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" name="submit" value="Delete"  class="btn btn-outline-danger">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($categories->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>