<link rel="icon" href="<?php echo e(asset('shop/img/core-img/favicon.ico')); ?>">
<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
<!-- Core Style CSS -->
<link rel="stylesheet" href="<?php echo e(asset('shop/css/core-style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('shop/style.css')); ?>">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<?php echo $__env->yieldPushContent('css'); ?>
<?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/layouts/css.blade.php ENDPATH**/ ?>