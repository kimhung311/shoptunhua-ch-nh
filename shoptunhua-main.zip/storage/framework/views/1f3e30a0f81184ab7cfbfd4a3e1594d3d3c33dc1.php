
<img src="/images/loginIcon.jpg" width="200" alt="">
<?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/components/application-logo.blade.php ENDPATH**/ ?>