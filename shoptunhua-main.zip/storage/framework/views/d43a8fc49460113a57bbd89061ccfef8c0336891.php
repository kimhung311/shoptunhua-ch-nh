<div class="mb-5 mt-5 border p-3">
    <form  action="<?php echo e(route('admin.product.index')); ?>" method="GET">
        <div class="row">
            <div class="col-6">
                <div class="mb-3">
                    <label class="form-label">Product Name</label>
                    <input type="text" class="form-control" name="name" placeholder="product name" value="<?php echo e(request()->get('name')); ?>">
                </div>
            </div>
            <div class="col-6">
                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <select name="category_id" class="form-control">
                        <option value="">Search by Category</option>
                        <?php if(!empty($categories)): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryId => $categoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoryId+1); ?>" ><?php echo e($categoryName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
        </div>
        
        
        
        
        <div class="mb-3">
            <button type="submit" class="btn btn-outline-primary">Search</button>
        </div>
    </form>
</div><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/admin/products/_search.blade.php ENDPATH**/ ?>