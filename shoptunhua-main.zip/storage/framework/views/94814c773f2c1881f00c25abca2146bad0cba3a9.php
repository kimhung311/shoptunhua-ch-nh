<?php if($errors->any()): ?>
    <div class="mb-5">
        <?php echo implode('', $errors->all('<div class="text-danger mb-1">:message</div>')); ?>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\shoptunhua-main\resources\views/errors/error.blade.php ENDPATH**/ ?>